<div align="center">

  [![Typing SVG](https://readme-typing-svg.demolab.com/?lines=New+website+released;Html+on+TOP;FOLLOW+US!;vscode+best;JOIN+THE+DISC;.................;)](https://git.io/typing-svg)
  
  ![](https://komarev.com/ghpvc/?username=thepizzaedition)

  <img src="https://img.shields.io/badge/Knows-CSS-blue/?logo=CSS&logoColor=warning&color=blue" alt="css">
  
  <img src="https://img.shields.io/badge/Knows-HTML-blue/?logo=html5&logoColor=warning&color=orange" alt="html">

  [![GitHub Streak](http://github-readme-streak-stats.herokuapp.com?user=thepizzaedition&theme=dark&background=000000)](https://git.io/streak-stats)

  [![Top Langs](https://github-readme-stats.vercel.app/api/top-langs/?username=thepizzaedition&layout=compact&theme=vision-friendly-dark)](https://github.com/anuraghazra/github-readme-stats)

</div>
